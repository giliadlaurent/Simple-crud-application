@extends('layout.view')
@section('contents')

{{--  <div class="container">
    <div class="row">
        <div class="col-sm-6">
            @include('components.alert')
           <div class="container">
            <form action="{{ route('/login') }}" method="post">
                {{ csrf_field() }}
                <div class="row">
                    <div class="col-md-8">
                    <div class="form-group">
                      <label for="email">Username</label>
                      <input type="email" class="form-control" placeholder="Email" name="email" id="email">
                   </div>
                    </div>
                      <div class="col-md-8">
                    <div class="form-group">
                      <label for="address">Password</label>
                      <input type="text" class="form-control" placeholder="Address" name="address" id="address">
                   </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary btn" >Login</button>
                {{--  <a href="{{ route('login.index') }}" class="btn btn-danger">register</a> 
              </form> 
           </div>
      </div>
  </div>
           </div>
            
        </div>
    </div>
</div>--}}
 <h1>Form</h1>

{!! Form::open(['action' =>'Work_place@reg','method' =>'POST']) !!}
<div class="form-group">
 {!! Form::label('title'=>'username') !!}
 {!! Form::text('name'=>'username', 'class'=>'form-control') !!}
</div>
<div class="form-group">
    {!! Form::label('title'=>'password') !!}
    {!! Form::password('name'=>'password', 'class'=>'form-control') !!}
   </div>
   {!! Form::submit('submit',['class'=>'btn btn-primary']) !!}
   {!! Form::close() !!}
   
   
@endsection