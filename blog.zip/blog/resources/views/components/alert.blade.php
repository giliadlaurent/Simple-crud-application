{{--  
        @if ($errors->has(''))
              <div class="alert alert-btn btn-danger">
                  <ul>
                      @foreach ($errors->get('roll') as $massage)
                          <li>{{ $massage }}</li>
                      @endforeach
                  </ul>
              </div>
          @endif  --}}
           @if ($errors->any())
			    <div class="alert alert-btn btn-danger">
			        
			            @foreach ($errors->all() as $massage)
                        {{$massage}}
			            @endforeach
			        
			    </div>
            @endif
           