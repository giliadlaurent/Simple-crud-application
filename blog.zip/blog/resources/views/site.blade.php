@extends('layouts.app')

@section('content')

<div class="alert alert-primary" role="alert">
    <strong>primary</strong>
</div>
<div class="alert alert-warning alert-dismissible fade show" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
  <strong>output</strong> 
      <ul>
        
    
      </ul>
 
</div>

<script>
  $(".alert").alert();
</script>
@endsection
