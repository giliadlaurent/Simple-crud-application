      <?php echo $__env->yieldContent('title'); ?>
      <?php $__env->startSection('title','My-app'); ?>
      <?php $__env->startSection('contents'); ?>
       <ul class="nav nav-pills">
             <li class="nav-item">
                   <a href="#" class="nav-link active">Active</a>
             </li>
             <li class="nav-item dropdown">
                   <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Dropdown</a>
                   <div class="dropdown-menu">
                         <a class="dropdown-item" href="#">Action</a>
                         <a class="dropdown-item" href="#">Another action</a>
                         <div class="dropdown-divider"></div>
                         <a class="dropdown-item" href="#">Action</a>
                   </div>
             </li>
             <li class="nav-item">
                   <a href="#" class="nav-link">Another link</a>
             </li>
             <li class="nav-item">
                   <a href="#" class="nav-link disabled">Disabled</a>
             </li>
       </ul>
       
      <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.view', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>