 
   
<?php $__env->startSection('content'); ?>
   
   <div class="container">
  <div class="jumbotron">
    <h1>Student Data</h1>
  </div>
  <div class="card-title btn btn-primary">
	Create New Student
</div>
 <div class="card">
    
      <div class="card-body">
      	 
			<?php echo $__env->make('components.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	 	 <form action="<?php echo e(route('i.store')); ?>" method="post">
	 	 	<?php echo e(csrf_field()); ?>

			  <div class="row">
			  	<div class="col-md-4">
			  	<div class="form-group">
				    <label for="roll">Roll Number</label>
					<input type="text" class="form-control" placeholder="Roll Number" name="roll" id="email">
				
				 </div>
			  	</div>
			  	<div class="col-md-8">
			  	<div class="form-group">
				    <label for="roll">Student Name <span class="required">*</span></label>
					 <input type="text" class="form-control"placeholder="Student Name" name="name" id="name">
					 <textarea id="my-editor" name="content" class="form-control"><?php echo old('content', 'test editor content'); ?></textarea>
					 
				 </div>
			  	</div>
			  	<div class="col-md-6">
			  	<div class="form-group">
				    <label for="email">Email</label>
				    <input type="email" class="form-control" placeholder="Email" name="email" id="email">
				 </div>
			  	</div>
			  	<div class="col-md-6">
			  	<div class="form-group">
				    <label for="phone">Phone</label>
				    <input type="text" class="form-control" placeholder="Phone" name="phone" id="phone">
				 </div>
			  	</div>
			        <div class="col-md-12">
			  	<div class="form-group">
				    <label for="address">Address</label>
				    <input type="text" class="form-control" placeholder="Address" name="address" id="address">
				 </div>
			  	</div>
			  </div>
			  <button type="submit" class="btn btn-primary"  onclick="return confirm('is data correct?.')">Add</button>
			  <a href="<?php echo e(route('i.index')); ?>" class="btn btn-danger">Back</a>
			</form> 
   	  </div>
    </div>
</div>
   
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>