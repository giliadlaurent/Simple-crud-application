<?php $__env->startSection('content'); ?>

<div class="alert alert-primary" role="alert">
    <strong>primary</strong>
</div>
<div class="alert alert-warning alert-dismissible fade show" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
  <strong>output</strong> 
      <ul>
        
    
      </ul>
 
</div>

<script>
  $(".alert").alert();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>