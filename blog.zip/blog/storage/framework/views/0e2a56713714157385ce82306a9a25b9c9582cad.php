<?php $__env->startSection('contents'); ?>

<div class="container">
    <div class="row">
        <div class="col-sm-6">
            <?php echo $__env->make('components.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
           <div class="container">
            <form action="<?php echo e(route('login.store')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <div class="row">
                    <div class="col-md-8">
                    <div class="form-group">
                      <label for="email">Username</label>
                      <input type="email" class="form-control" placeholder="Email" name="email" id="email">
                   </div>
                    </div>
                      <div class="col-md-8">
                    <div class="form-group">
                      <label for="address">Password</label>
                      <input type="text" class="form-control" placeholder="Address" name="address" id="address">
                   </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary btn" >Login</button>
                
              </form> 
           </div>
      </div>
  </div>
           </div>
            
        </div>
    </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.view', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>