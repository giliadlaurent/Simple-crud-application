<?php echo $__env->make('layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<nav class="breadcrumb">
    <a class="breadcrumb-item" href="<?php echo e(asset('site')); ?>">Site</a>
    <a class="breadcrumb-item" href="#">about</a>
    <span class="breadcrumb-item active"></span>
</nav>
 



