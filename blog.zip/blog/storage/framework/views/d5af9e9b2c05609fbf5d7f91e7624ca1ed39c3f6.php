<?php $__env->startSection('content'); ?>
   <div class="container">
  <div class="jumbotron">
    <h1>Laravel Simple CRUD Operation</h1>
    <p> Student Data.</p>
  </div>
     <?php if(Session::has('message')): ?>
     <p class="alert alert-success"><?php echo e(Session::get('message')); ?></p>
     <?php endif; ?>
 <div class="panel panel-primary">
      <div class="panel-heading">
	<a href="<?php echo e(action('PostController@create')); ?>" data-toggle="modal" data-target="#addModal" class="btn btn-default btn-sm"><i class="glyphicon glyphicon-plus"></i> Add New</a>
      </div>
      <div class="panel-body">
	 	<table class="table table-hover table-bordered table-stripped">
	 		<thead>
	 			<tr>
	 			<th>S.N</th>
	 			<th>Name</th>
	 			<th>Roll No.</th>
	 			<th>Phone</th>
	 			<th>Email</th>
	 			<th>Address</th>
	 			<th style="width:200px;">Action</th>
	 			</tr>
	 		</thead>
	 		<tbody>
	 		    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	 			<tr>
	 			<td><?php echo e($loop->index+1); ?></td>
	 			<td><?php echo e($student->name); ?></td>
	 			<td><?php echo e($student->roll); ?></td>
	 			<td><?php echo e($student->phone); ?></td>
	 			<td><?php echo e($student->email); ?></td>
	 			<td><?php echo e($student->address); ?></td>
	 			<td>
	 		<form  method="post" action="<?php echo e(route('i.destroy',$student->id)); ?>" class="btn btn-xs ">
                	        <?php echo e(csrf_field()); ?>    
                		<?php echo e(method_field('DELETE')); ?>

                		<a href="<?php echo e(route('i.edit',$student->id)); ?>" class="btn btn-xs btn-primary  ">Edit</a>
                		
	 			<a href="<?php echo e(route('i.show',$student->id)); ?>" class="btn btn-xs btn-success ">View</a>

                        <button class="btn btn-xs btn-danger" type="submit" onclick="return confirm('Are You Sure? Want to Delete It.');">Delete</button>
                	</form>
	 		</td>
	 		</tr>
			 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			 
	 		</tbody>
	 	</table>
	 	<p class="pull-right">
	 	<?php echo e($students->links()); ?>

	 	</p>
   	  </div>
    </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>