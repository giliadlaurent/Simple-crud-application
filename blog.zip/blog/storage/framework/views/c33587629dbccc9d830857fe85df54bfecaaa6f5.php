


<?php echo $__env->make('layout.link', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<button class="btn">
        Notification <span class="badge badge-primary"></span>
</button>

<?php if(count($post) > 0): ?>
<?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h1><?php echo e($item->title); ?></h1>
    <h1><?php echo e($item->author); ?></h1>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
<?php else: ?>
    <h1>no data</h1>
<?php endif; ?>