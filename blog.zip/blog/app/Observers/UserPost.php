<?php

namespace App\Observers;

class UserPost
{
    //
}
