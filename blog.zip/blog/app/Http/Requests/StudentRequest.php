<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StudentRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return false;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name'=>'required|unique:posts',
            'roll'=>'required|unique:posts|present:posts',
            'email'=>'required|unique:posts',
            'phone'=>'required|unique:posts',
            'address'=>'required|unique:posts',
        ];
    }
}
