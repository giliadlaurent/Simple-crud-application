<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Log;
use Illuminate\Http\Request;
use App\Post;
class PostController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth:web');
    }
    public function index()
    {
        //
        $students = Post::paginate(3);
        return view('dashboard.index')->with('students',$students);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('dashboard.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StudentPost $request)
    {    
        // // Validate the Field
        // $this->validate($request,[
        //     'name'=>'required|unique:posts',
        //     'roll'=>'required|unique:posts|present:posts',
        //     'email'=>'required|unique:posts',
        //     'phone'=>'required|unique:posts',
        //     'address'=>'required|unique:posts',
        // ]);
        $student = new Post();
        $student=$request->all();
        $student->save();
        return redirect()->route('i.index')->with('message','New Student Created Successfull !');
       
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        // Log::info('Showing user profile for user:'.$id); 
        $student = Post::findOrFail($id);
        return view('dashboard.show')->with('student',$student);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //edit data of students
        $student = Post::find($id);
        return view('dashboard.edit')->with('student',$student);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // Validate the Field
        $this->validate($request,[
            'name'=>'required|unique:posts',
            'roll'=>'required',
            'email'=>'required',
            'phone'=>'required',
            'address'=>'required',
        ]);
        $student = Post::find($id);
        $student=$request->all()->save();
 ;       return redirect()->route('i.index')->with('message','Student Updated Successfull !');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //destroy data in database
        $student = Post::find($id)->delete();
        return back()->with('message','Student Deleted Successfull !');
    }
}
